from django.shortcuts import render
from .models import Pesticide

# Create your views here.
def index(request):
    pesticides_list= Pesticide.objects.all()
    return render(request,'index.html',{'pesticides':pesticides_list})

