from django.contrib import admin

# Register your models here.
from .form import Pesticide
# Register your models here.
admin.site.register(Pesticide)