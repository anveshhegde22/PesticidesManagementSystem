from django.db import models

# Create your models here.
class Pesticide(models.Model):
    Name = models.CharField(max_length=100)
    Picture = models.ImageField()
    Price = models.CharField(max_length=100)
    Description = models.TextField()

    def __str__(self):
        result=self.Name+" --> "+ self.Price
        return result

    class Meta:
        db_table="pesticides"
